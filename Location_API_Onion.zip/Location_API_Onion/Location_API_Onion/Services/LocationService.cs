﻿using Location_API_Onion.Infrastructure.Interface;
using Location_API_Onion.Models;
using LocationAPI.Onion.Infrastructure.Interfaces;

namespace Location_API_Onion.Services
{
 
        public class LocationService : ILocationService
        {
            private readonly ILocationRepository _repository;

            public LocationService(ILocationRepository repository)
            {
                _repository = repository;
            }

            #region Country Methods
            public async Task<List<Country>> GetCountriesAsync()
            {
                return await _repository.GetCountriesAsync();
            }

            public async Task<Country?> GetCountryByIdAsync(int id)
            {
                return await _repository.GetCountryByIdAsync(id);
            }

            public async Task<int> CreateCountryAsync(Country country)
            {
                return await _repository.CreateCountryAsync(country);
            }

            public async Task<bool> UpdateCountryAsync(Country country)
            {
                var exists = await _repository.CountryExistsAsync(country.CountryID);
                if (!exists)
                {
                    return false;
                }

                return await _repository.UpdateCountryAsync(country);
            }

            public async Task<bool> DeleteCountryAsync(int id)
            {
                var exists = await _repository.CountryExistsAsync(id);
                if (!exists)
                {
                    return false;
                }

                return await _repository.DeleteCountryAsync(id);
            }
            #endregion

            #region Province Methods
            public async Task<List<Province>> GetProvincesAsync()
            {
                return await _repository.GetProvincesAsync();
            }

            public async Task<Province?> GetProvinceByIdAsync(int id)
            {
                return await _repository.GetProvinceByIdAsync(id);
            }

            public async Task<List<Province>> GetProvincesByCountryIdAsync(int countryId)
            {
                return await _repository.GetProvincesByCountryIdAsync(countryId);
            }

            public async Task<int> CreateProvinceAsync(Province province)
            {
                var countryExists = await _repository.CountryExistsAsync(province.CountryID);
                if (!countryExists)
                {
                    throw new ArgumentException("Country does not exist");
                }

                return await _repository.CreateProvinceAsync(province);
            }

            public async Task<bool> UpdateProvinceAsync(Province province)
            {
                var exists = await _repository.ProvinceExistsAsync(province.ProvinceID);
                if (!exists)
                {
                    return false;
                }

                var countryExists = await _repository.CountryExistsAsync(province.CountryID);
                if (!countryExists)
                {
                    throw new ArgumentException("Country does not exist");
                }

                return await _repository.UpdateProvinceAsync(province);
            }

            public async Task<bool> DeleteProvinceAsync(int id)
            {
                var exists = await _repository.ProvinceExistsAsync(id);
                if (!exists)
                {
                    return false;
                }

                return await _repository.DeleteProvinceAsync(id);
            }
            #endregion

            #region City Methods
            public async Task<List<City>> GetCitiesAsync()
            {
                return await _repository.GetCitiesAsync();
            }

            public async Task<City?> GetCityByIdAsync(int id)
            {
                return await _repository.GetCityByIdAsync(id);
            }

            public async Task<List<City>> GetCitiesByProvinceIdAsync(int provinceId)
            {
                return await _repository.GetCitiesByProvinceIdAsync(provinceId);
            }

            public async Task<int> CreateCityAsync(City city)
            {
                var provinceExists = await _repository.ProvinceExistsAsync(city.ProvinceID);
                if (!provinceExists)
                {
                    throw new ArgumentException("Province does not exist");
                }

                return await _repository.CreateCityAsync(city);
            }

            public async Task<bool> UpdateCityAsync(City city)
            {
                var exists = await _repository.CityExistsAsync(city.CityID);
                if (!exists)
                {
                    return false;
                }

                var provinceExists = await _repository.ProvinceExistsAsync(city.ProvinceID);
                if (!provinceExists)
                {
                    throw new ArgumentException("Province does not exist");
                }

                return await _repository.UpdateCityAsync(city);
            }

            public async Task<bool> DeleteCityAsync(int id)
            {
                var exists = await _repository.CityExistsAsync(id);
                if (!exists)
                {
                    return false;
                }

                return await _repository.DeleteCityAsync(id);
            }
            #endregion

            #region PostalCode Methods
            public async Task<List<PostalCode>> GetPostalCodesAsync()
            {
                return await _repository.GetPostalCodesAsync();
            }

            public async Task<PostalCode?> GetPostalCodeByIdAsync(int id)
            {
                return await _repository.GetPostalCodeByIdAsync(id);
            }

            public async Task<List<PostalCode>> GetPostalCodesByCityIdAsync(int cityId)
            {
                return await _repository.GetPostalCodesByCityIdAsync(cityId);
            }

            public async Task<int> CreatePostalCodeAsync(PostalCode postalCode)
            {
                var cityExists = await _repository.CityExistsAsync(postalCode.CityID);
                if (!cityExists)
                {
                    throw new ArgumentException("City does not exist");
                }

                return await _repository.CreatePostalCodeAsync(postalCode);
            }

            public async Task<bool> UpdatePostalCodeAsync(PostalCode postalCode)
            {
                var exists = await _repository.PostalCodeExistsAsync(postalCode.PostalCodeID);
                if (!exists)
                {
                    return false;
                }

                var cityExists = await _repository.CityExistsAsync(postalCode.CityID);
                if (!cityExists)
                {
                    throw new ArgumentException("City does not exist");
                }

                return await _repository.UpdatePostalCodeAsync(postalCode);
            }

            public async Task<bool> DeletePostalCodeAsync(int id)
            {
                var exists = await _repository.PostalCodeExistsAsync(id);
                if (!exists)
                {
                    return false;
                }

                return await _repository.DeletePostalCodeAsync(id);
            }
            #endregion
        }
    }
