﻿using Location_API_Onion.Infrastructure.Interface;
using Location_API_Onion.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Location_API_Onion.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountryController : ControllerBase
    {
        private readonly ILocationService _service;

        public CountryController(ILocationService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Country>>> GetCountries()
        {
            try
            {
                var data = await _service.GetCountriesAsync();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Country>> GetCountryById(int id)
        {
            try
            {
                var country = await _service.GetCountryByIdAsync(id);
                if (country == null)
                {
                    return NotFound();
                }

                return Ok(country);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost]
        public async Task<ActionResult<Country>> CreateCountry([FromBody] Country country)
        {
            try
            {
                if (country == null)
                {
                    return BadRequest("Country data is required.");
                }

                var countryId = await _service.CreateCountryAsync(country);
                country.CountryID = countryId;

                return CreatedAtAction(nameof(GetCountryById), new { id = country.CountryID }, country);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCountry(int id, [FromBody] Country country)
        {
            try
            {
                if (country == null)
                {
                    return BadRequest("Country data is required.");
                }

                if (id != country.CountryID)
                {
                    return BadRequest("Country ID mismatch.");
                }

                var success = await _service.UpdateCountryAsync(country);
                if (!success)
                {
                    return NotFound();
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<Country>> DeleteCountry(int id)
        {
            try
            {
                var country = await _service.GetCountryByIdAsync(id);
                if (country == null)
                {
                    return NotFound();
                }

                var success = await _service.DeleteCountryAsync(id);
                if (!success)
                {
                    return StatusCode(500, "Failed to delete country.");
                }

                return Ok(country);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
