﻿using Location_API_Onion.Infrastructure.Interface;
using Location_API_Onion.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Location_API_Onion.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CityController : ControllerBase
    {
        private readonly ILocationService _service;

        public CityController(ILocationService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<City>>> GetCities()
        {
            try
            {
                var data = await _service.GetCitiesAsync();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<City>> GetCityById(int id)
        {
            try
            {
                var city = await _service.GetCityByIdAsync(id);
                if (city == null)
                {
                    return NotFound();
                }

                return Ok(city);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("province/{provinceId}")]
        public async Task<ActionResult<IEnumerable<City>>> GetCitiesByProvinceId(int provinceId)
        {
            try
            {
                var data = await _service.GetCitiesByProvinceIdAsync(provinceId);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost]
        public async Task<ActionResult<City>> CreateCity([FromBody] City city)
        {
            try
            {
                if (city == null)
                {
                    return BadRequest("City data is required.");
                }

                var cityId = await _service.CreateCityAsync(city);
                city.CityID = cityId;

                return CreatedAtAction(nameof(GetCityById), new { id = city.CityID }, city);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCity(int id, [FromBody] City city)
        {
            try
            {
                if (city == null)
                {
                    return BadRequest("City data is required.");
                }

                if (id != city.CityID)
                {
                    return BadRequest("City ID mismatch.");
                }

                var success = await _service.UpdateCityAsync(city);
                if (!success)
                {
                    return NotFound();
                }

                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<City>> DeleteCity(int id)
        {
            try
            {
                var city = await _service.GetCityByIdAsync(id);
                if (city == null)
                {
                    return NotFound();
                }

                var success = await _service.DeleteCityAsync(id);
                if (!success)
                {
                    return StatusCode(500, "Failed to delete city.");
                }

                return Ok(city);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
