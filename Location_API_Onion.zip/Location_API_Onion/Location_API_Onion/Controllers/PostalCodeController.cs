﻿using Location_API_Onion.Infrastructure.Interface;
using Location_API_Onion.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Location_API_Onion.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostalCodeController : ControllerBase
    {

        private readonly ILocationService _service;

        public PostalCodeController(ILocationService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<PostalCode>>> GetPostalCodes()
        {
            try
            {
                var data = await _service.GetPostalCodesAsync();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<PostalCode>> GetPostalCodeById(int id)
        {
            try
            {
                var postalCode = await _service.GetPostalCodeByIdAsync(id);
                if (postalCode == null)
                {
                    return NotFound();
                }

                return Ok(postalCode);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("city/{cityId}")]
        public async Task<ActionResult<IEnumerable<PostalCode>>> GetPostalCodesByCityId(int cityId)
        {
            try
            {
                var data = await _service.GetPostalCodesByCityIdAsync(cityId);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost]
        public async Task<ActionResult<PostalCode>> CreatePostalCode([FromBody] PostalCode postalCode)
        {
            try
            {
                if (postalCode == null)
                {
                    return BadRequest("PostalCode data is required.");
                }

                var postalCodeId = await _service.CreatePostalCodeAsync(postalCode);
                postalCode.PostalCodeID = postalCodeId;

                return CreatedAtAction(nameof(GetPostalCodeById), new { id = postalCode.PostalCodeID }, postalCode);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePostalCode(int id, [FromBody] PostalCode postalCode)
        {
            try
            {
                if (postalCode == null)
                {
                    return BadRequest("PostalCode data is required.");
                }

                if (id != postalCode.PostalCodeID)
                {
                    return BadRequest("PostalCode ID mismatch.");
                }

                var success = await _service.UpdatePostalCodeAsync(postalCode);
                if (!success)
                {
                    return NotFound();
                }

                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<PostalCode>> DeletePostalCode(int id)
        {
            try
            {
                var postalCode = await _service.GetPostalCodeByIdAsync(id);
                if (postalCode == null)
                {
                    return NotFound();
                }

                var success = await _service.DeletePostalCodeAsync(id);
                if (!success)
                {
                    return StatusCode(500, "Failed to delete postal code.");
                }

                return Ok(postalCode);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
