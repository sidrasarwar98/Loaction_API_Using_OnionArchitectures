﻿using Location_API_Onion.Infrastructure.Interface;
using Location_API_Onion.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Location_API_Onion.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProvinceController : ControllerBase
    {
        private readonly ILocationService _service;

        public ProvinceController(ILocationService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Province>>> GetProvinces()
        {
            try
            {
                var data = await _service.GetProvincesAsync();
                return Ok(data);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Province>> GetProvinceById(int id)
        {
            try
            {
                var province = await _service.GetProvinceByIdAsync(id);
                if (province == null)
                {
                    return NotFound();
                }

                return Ok(province);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("country/{countryId}")]
        public async Task<ActionResult<IEnumerable<Province>>> GetProvincesByCountryId(int countryId)
        {
            try
            {
                var data = await _service.GetProvincesByCountryIdAsync(countryId);
                return Ok(data);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost]
        public async Task<ActionResult<Province>> CreateProvince([FromBody] Province province)
        {
            try
            {
                if (province == null)
                {
                    return BadRequest("Province data is required.");
                }

                var provinceId = await _service.CreateProvinceAsync(province);
                province.ProvinceID = provinceId;

                return CreatedAtAction(nameof(GetProvinceById), new { id = province.ProvinceID }, province);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProvince(int id, [FromBody] Province province)
        {
            try
            {
                if (province == null)
                {
                    return BadRequest("Province data is required.");
                }

                if (id != province.ProvinceID)
                {
                    return BadRequest("Province ID mismatch.");
                }

                var success = await _service.UpdateProvinceAsync(province);
                if (!success)
                {
                    return NotFound();
                }

                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<Province>> DeleteProvince(int id)
        {
            try
            {
                var province = await _service.GetProvinceByIdAsync(id);
                if (province == null)
                {
                    return NotFound();
                }

                var success = await _service.DeleteProvinceAsync(id);
                if (!success)
                {
                    return StatusCode(500, "Failed to delete province.");
                }

                return Ok(province);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
    