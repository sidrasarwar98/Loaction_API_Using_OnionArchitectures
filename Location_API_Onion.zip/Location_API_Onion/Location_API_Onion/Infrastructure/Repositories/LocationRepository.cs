﻿using Location_API_Onion.Models;
using LocationAPI.Onion.Infrastructure.Interfaces;
using Microsoft.Data.SqlClient;




namespace LocationAPI.Onion.Infrastructure.Repositories
{
 
        public class LocationRepository : ILocationRepository
        {
            private readonly string _connectionString;

            public LocationRepository(string connectionString)
            {
                _connectionString = connectionString;
            }

            private SqlConnection GetConnection()
            {
                return new SqlConnection(_connectionString);
            }

            #region Country Methods
            public async Task<List<Country>> GetCountriesAsync()
            {
                var countries = new List<Country>();

                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand("SELECT CountryID, CountryName FROM Country", connection))
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            countries.Add(new Country
                            {
                                CountryID = reader.GetInt32(0),
                                CountryName = reader.GetString(1)
                            });
                        }
                    }
                }

                return countries;
            }

            public async Task<Country?> GetCountryByIdAsync(int id)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand("SELECT CountryID, CountryName FROM Country WHERE CountryID = @Id", connection))
                    {
                        command.Parameters.AddWithValue("@Id", id);

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                return new Country
                                {
                                    CountryID = reader.GetInt32(0),
                                    CountryName = reader.GetString(1)
                                };
                            }
                        }
                    }
                }

                return null;
            }

            public async Task<int> CreateCountryAsync(Country country)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "INSERT INTO Country (CountryName) OUTPUT INSERTED.CountryID VALUES (@Name)",
                        connection))
                    {
                        command.Parameters.AddWithValue("@Name", country.CountryName);

                        var result = await command.ExecuteScalarAsync();
                        return Convert.ToInt32(result);
                    }
                }
            }

            public async Task<bool> UpdateCountryAsync(Country country)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "UPDATE Country SET CountryName = @Name WHERE CountryID = @Id",
                        connection))
                    {
                        command.Parameters.AddWithValue("@Id", country.CountryID);
                        command.Parameters.AddWithValue("@Name", country.CountryName);

                        var rowsAffected = await command.ExecuteNonQueryAsync();
                        return rowsAffected > 0;
                    }
                }
            }

            public async Task<bool> DeleteCountryAsync(int id)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand("DELETE FROM Country WHERE CountryID = @Id", connection))
                    {
                        command.Parameters.AddWithValue("@Id", id);

                        var rowsAffected = await command.ExecuteNonQueryAsync();
                        return rowsAffected > 0;
                    }
                }
            }

            public async Task<bool> CountryExistsAsync(int id)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand("SELECT COUNT(1) FROM Country WHERE CountryID = @Id", connection))
                    {
                        command.Parameters.AddWithValue("@Id", id);

                        var result = await command.ExecuteScalarAsync();
                        return Convert.ToInt32(result) > 0;
                    }
                }
            }
            #endregion

            #region Province Methods
            public async Task<List<Province>> GetProvincesAsync()
            {
                var provinces = new List<Province>();

                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "SELECT p.ProvinceID, p.ProvinceName, p.CountryID, c.CountryName " +
                        "FROM Province p INNER JOIN Country c ON p.CountryID = c.CountryID",
                        connection))
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            provinces.Add(new Province
                            {
                                ProvinceID = reader.GetInt32(0),
                                ProvinceName = reader.GetString(1),
                                CountryID = reader.GetInt32(2),
                                CountryName = reader.GetString(3)
                            });
                        }
                    }
                }

                return provinces;
            }

            public async Task<Province?> GetProvinceByIdAsync(int id)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "SELECT p.ProvinceID, p.ProvinceName, p.CountryID, c.CountryName " +
                        "FROM Province p INNER JOIN Country c ON p.CountryID = c.CountryID " +
                        "WHERE p.ProvinceID = @Id",
                        connection))
                    {
                        command.Parameters.AddWithValue("@Id", id);

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                return new Province
                                {
                                    ProvinceID = reader.GetInt32(0),
                                    ProvinceName = reader.GetString(1),
                                    CountryID = reader.GetInt32(2),
                                    CountryName = reader.GetString(3)
                                };
                            }
                        }
                    }
                }

                return null;
            }

            public async Task<List<Province>> GetProvincesByCountryIdAsync(int countryId)
            {
                var provinces = new List<Province>();

                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "SELECT p.ProvinceID, p.ProvinceName, p.CountryID, c.CountryName " +
                        "FROM Province p INNER JOIN Country c ON p.CountryID = c.CountryID " +
                        "WHERE p.CountryID = @CountryId",
                        connection))
                    {
                        command.Parameters.AddWithValue("@CountryId", countryId);

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                provinces.Add(new Province
                                {
                                    ProvinceID = reader.GetInt32(0),
                                    ProvinceName = reader.GetString(1),
                                    CountryID = reader.GetInt32(2),
                                    CountryName = reader.GetString(3)
                                });
                            }
                        }
                    }
                }

                return provinces;
            }

            public async Task<int> CreateProvinceAsync(Province province)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "INSERT INTO Province (ProvinceName, CountryID) OUTPUT INSERTED.ProvinceID VALUES (@Name, @CountryId)",
                        connection))
                    {
                        command.Parameters.AddWithValue("@Name", province.ProvinceName);
                        command.Parameters.AddWithValue("@CountryId", province.CountryID);

                        var result = await command.ExecuteScalarAsync();
                        return Convert.ToInt32(result);
                    }
                }
            }

            public async Task<bool> UpdateProvinceAsync(Province province)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "UPDATE Province SET ProvinceName = @Name, CountryID = @CountryId WHERE ProvinceID = @Id",
                        connection))
                    {
                        command.Parameters.AddWithValue("@Id", province.ProvinceID);
                        command.Parameters.AddWithValue("@Name", province.ProvinceName);
                        command.Parameters.AddWithValue("@CountryId", province.CountryID);

                        var rowsAffected = await command.ExecuteNonQueryAsync();
                        return rowsAffected > 0;
                    }
                }
            }

            public async Task<bool> DeleteProvinceAsync(int id)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand("DELETE FROM Province WHERE ProvinceID = @Id", connection))
                    {
                        command.Parameters.AddWithValue("@Id", id);

                        var rowsAffected = await command.ExecuteNonQueryAsync();
                        return rowsAffected > 0;
                    }
                }
            }

            public async Task<bool> ProvinceExistsAsync(int id)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand("SELECT COUNT(1) FROM Province WHERE ProvinceID = @Id", connection))
                    {
                        command.Parameters.AddWithValue("@Id", id);

                        var result = await command.ExecuteScalarAsync();
                        return Convert.ToInt32(result) > 0;
                    }
                }
            }
            #endregion

            #region City Methods
            public async Task<List<City>> GetCitiesAsync()
            {
                var cities = new List<City>();

                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "SELECT c.CityID, c.CityName, c.ProvinceID, p.ProvinceName, p.CountryID, co.CountryName " +
                        "FROM City c " +
                        "INNER JOIN Province p ON c.ProvinceID = p.ProvinceID " +
                        "INNER JOIN Country co ON p.CountryID = co.CountryID",
                        connection))
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            cities.Add(new City
                            {
                                CityID = reader.GetInt32(0),
                                CityName = reader.GetString(1),
                                ProvinceID = reader.GetInt32(2),
                                ProvinceName = reader.GetString(3),
                                CountryID = reader.GetInt32(4),
                                CountryName = reader.GetString(5)
                            });
                        }
                    }
                }

                return cities;
            }

            public async Task<City?> GetCityByIdAsync(int id)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "SELECT c.CityID, c.CityName, c.ProvinceID, p.ProvinceName, p.CountryID, co.CountryName " +
                        "FROM City c " +
                        "INNER JOIN Province p ON c.ProvinceID = p.ProvinceID " +
                        "INNER JOIN Country co ON p.CountryID = co.CountryID " +
                        "WHERE c.CityID = @Id",
                        connection))
                    {
                        command.Parameters.AddWithValue("@Id", id);

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                return new City
                                {
                                    CityID = reader.GetInt32(0),
                                    CityName = reader.GetString(1),
                                    ProvinceID = reader.GetInt32(2),
                                    ProvinceName = reader.GetString(3),
                                    CountryID = reader.GetInt32(4),
                                    CountryName = reader.GetString(5)
                                };
                            }
                        }
                    }
                }

                return null;
            }

            public async Task<List<City>> GetCitiesByProvinceIdAsync(int provinceId)
            {
                var cities = new List<City>();

                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "SELECT c.CityID, c.CityName, c.ProvinceID, p.ProvinceName, p.CountryID, co.CountryName " +
                        "FROM City c " +
                        "INNER JOIN Province p ON c.ProvinceID = p.ProvinceID " +
                        "INNER JOIN Country co ON p.CountryID = co.CountryID " +
                        "WHERE c.ProvinceID = @ProvinceId",
                        connection))
                    {
                        command.Parameters.AddWithValue("@ProvinceId", provinceId);

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                cities.Add(new City
                                {
                                    CityID = reader.GetInt32(0),
                                    CityName = reader.GetString(1),
                                    ProvinceID = reader.GetInt32(2),
                                    ProvinceName = reader.GetString(3),
                                    CountryID = reader.GetInt32(4),
                                    CountryName = reader.GetString(5)
                                });
                            }
                        }
                    }
                }

                return cities;
            }

            public async Task<int> CreateCityAsync(City city)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "INSERT INTO City (CityName, ProvinceID) OUTPUT INSERTED.CityID VALUES (@Name, @ProvinceId)",
                        connection))
                    {
                        command.Parameters.AddWithValue("@Name", city.CityName);
                        command.Parameters.AddWithValue("@ProvinceId", city.ProvinceID);

                        var result = await command.ExecuteScalarAsync();
                        return Convert.ToInt32(result);
                    }
                }
            }

            public async Task<bool> UpdateCityAsync(City city)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "UPDATE City SET CityName = @Name, ProvinceID = @ProvinceId WHERE CityID = @Id",
                        connection))
                    {
                        command.Parameters.AddWithValue("@Id", city.CityID);
                        command.Parameters.AddWithValue("@Name", city.CityName);
                        command.Parameters.AddWithValue("@ProvinceId", city.ProvinceID);

                        var rowsAffected = await command.ExecuteNonQueryAsync();
                        return rowsAffected > 0;
                    }
                }
            }

            public async Task<bool> DeleteCityAsync(int id)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand("DELETE FROM City WHERE CityID = @Id", connection))
                    {
                        command.Parameters.AddWithValue("@Id", id);

                        var rowsAffected = await command.ExecuteNonQueryAsync();
                        return rowsAffected > 0;
                    }
                }
            }

            public async Task<bool> CityExistsAsync(int id)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand("SELECT COUNT(1) FROM City WHERE CityID = @Id", connection))
                    {
                        command.Parameters.AddWithValue("@Id", id);

                        var result = await command.ExecuteScalarAsync();
                        return Convert.ToInt32(result) > 0;
                    }
                }
            }
            #endregion

            #region PostalCode Methods
            public async Task<List<PostalCode>> GetPostalCodesAsync()
            {
                var postalCodes = new List<PostalCode>();

                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "SELECT pc.PostalCodeID, pc.Code, pc.CityID, c.CityName, c.ProvinceID, p.ProvinceName, p.CountryID, co.CountryName " +
                        "FROM PostalCode pc " +
                        "INNER JOIN City c ON pc.CityID = c.CityID " +
                        "INNER JOIN Province p ON c.ProvinceID = p.ProvinceID " +
                        "INNER JOIN Country co ON p.CountryID = co.CountryID",
                        connection))
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            postalCodes.Add(new PostalCode
                            {
                                PostalCodeID = reader.GetInt32(0),
                                Code = reader.GetString(1),
                                CityID = reader.GetInt32(2),
                                CityName = reader.GetString(3),
                                ProvinceID = reader.GetInt32(4),
                                ProvinceName = reader.GetString(5),
                                CountryID = reader.GetInt32(6),
                                CountryName = reader.GetString(7)
                            });
                        }
                    }
                }

                return postalCodes;
            }

            public async Task<PostalCode?> GetPostalCodeByIdAsync(int id)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "SELECT pc.PostalCodeID, pc.Code, pc.CityID, c.CityName, c.ProvinceID, p.ProvinceName, p.CountryID, co.CountryName " +
                        "FROM PostalCode pc " +
                        "INNER JOIN City c ON pc.CityID = c.CityID " +
                        "INNER JOIN Province p ON c.ProvinceID = p.ProvinceID " +
                        "INNER JOIN Country co ON p.CountryID = co.CountryID " +
                        "WHERE pc.PostalCodeID = @Id",
                        connection))
                    {
                        command.Parameters.AddWithValue("@Id", id);

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                return new PostalCode
                                {
                                    PostalCodeID = reader.GetInt32(0),
                                    Code = reader.GetString(1),
                                    CityID = reader.GetInt32(2),
                                    CityName = reader.GetString(3),
                                    ProvinceID = reader.GetInt32(4),
                                    ProvinceName = reader.GetString(5),
                                    CountryID = reader.GetInt32(6),
                                    CountryName = reader.GetString(7)
                                };
                            }
                        }
                    }
                }

                return null;
            }

            public async Task<List<PostalCode>> GetPostalCodesByCityIdAsync(int cityId)
            {
                var postalCodes = new List<PostalCode>();

                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "SELECT pc.PostalCodeID, pc.Code, pc.CityID, c.CityName, c.ProvinceID, p.ProvinceName, p.CountryID, co.CountryName " +
                        "FROM PostalCode pc " +
                        "INNER JOIN City c ON pc.CityID = c.CityID " +
                        "INNER JOIN Province p ON c.ProvinceID = p.ProvinceID " +
                        "INNER JOIN Country co ON p.CountryID = co.CountryID " +
                        "WHERE pc.CityID = @CityId",
                        connection))
                    {
                        command.Parameters.AddWithValue("@CityId", cityId);

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                postalCodes.Add(new PostalCode
                                {
                                    PostalCodeID = reader.GetInt32(0),
                                    Code = reader.GetString(1),
                                    CityID = reader.GetInt32(2),
                                    CityName = reader.GetString(3),
                                    ProvinceID = reader.GetInt32(4),
                                    ProvinceName = reader.GetString(5),
                                    CountryID = reader.GetInt32(6),
                                    CountryName = reader.GetString(7)
                                });
                            }
                        }
                    }
                }

                return postalCodes;
            }

            public async Task<int> CreatePostalCodeAsync(PostalCode postalCode)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "INSERT INTO PostalCode (Code, CityID) OUTPUT INSERTED.PostalCodeID VALUES (@Code, @CityId)",
                        connection))
                    {
                        command.Parameters.AddWithValue("@Code", postalCode.Code);
                        command.Parameters.AddWithValue("@CityId", postalCode.CityID);

                        var result = await command.ExecuteScalarAsync();
                        return Convert.ToInt32(result);
                    }
                }
            }

            public async Task<bool> UpdatePostalCodeAsync(PostalCode postalCode)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand(
                        "UPDATE PostalCode SET Code = @Code, CityID = @CityId WHERE PostalCodeID = @Id",
                        connection))
                    {
                        command.Parameters.AddWithValue("@Id", postalCode.PostalCodeID);
                        command.Parameters.AddWithValue("@Code", postalCode.Code);
                        command.Parameters.AddWithValue("@CityId", postalCode.CityID);

                        var rowsAffected = await command.ExecuteNonQueryAsync();
                        return rowsAffected > 0;
                    }
                }
            }

            public async Task<bool> DeletePostalCodeAsync(int id)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand("DELETE FROM PostalCode WHERE PostalCodeID = @Id", connection))
                    {
                        command.Parameters.AddWithValue("@Id", id);

                        var rowsAffected = await command.ExecuteNonQueryAsync();
                        return rowsAffected > 0;
                    }
                }
            }

            public async Task<bool> PostalCodeExistsAsync(int id)
            {
                using (var connection = GetConnection())
                {
                    await connection.OpenAsync();

                    using (var command = new SqlCommand("SELECT COUNT(1) FROM PostalCode WHERE PostalCodeID = @Id", connection))
                    {
                        command.Parameters.AddWithValue("@Id", id);

                        var result = await command.ExecuteScalarAsync();
                        return Convert.ToInt32(result) > 0;
                    }
                }
            }
            #endregion
        }
    }

