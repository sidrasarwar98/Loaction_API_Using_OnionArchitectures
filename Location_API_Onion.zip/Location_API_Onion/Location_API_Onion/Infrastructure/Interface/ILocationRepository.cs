﻿//namespace Location_API_Onion.Infrastructure.Interface
//{
//    public interface ILocationRepository
//    {
//    }
//}
using Location_API_Onion.Models;


namespace LocationAPI.Onion.Infrastructure.Interfaces
{
    public interface ILocationRepository
    {
        #region Country Methods
        Task<List<Country>> GetCountriesAsync();
        Task<Country?> GetCountryByIdAsync(int id);
        Task<int> CreateCountryAsync(Country country);
        Task<bool> UpdateCountryAsync(Country country);
        Task<bool> DeleteCountryAsync(int id);
        Task<bool> CountryExistsAsync(int id);
        #endregion

        #region Province Methods
        Task<List<Province>> GetProvincesAsync();
        Task<Province?> GetProvinceByIdAsync(int id);
        Task<List<Province>> GetProvincesByCountryIdAsync(int countryId);
        Task<int> CreateProvinceAsync(Province province);
        Task<bool> UpdateProvinceAsync(Province province);
        Task<bool> DeleteProvinceAsync(int id);
        Task<bool> ProvinceExistsAsync(int id);
        #endregion

        #region City Methods
        Task<List<City>> GetCitiesAsync();
        Task<City?> GetCityByIdAsync(int id);
        Task<List<City>> GetCitiesByProvinceIdAsync(int provinceId);
        Task<int> CreateCityAsync(City city);
        Task<bool> UpdateCityAsync(City city);
        Task<bool> DeleteCityAsync(int id);
        Task<bool> CityExistsAsync(int id);
        #endregion

        #region PostalCode Methods
        Task<List<PostalCode>> GetPostalCodesAsync();
        Task<PostalCode?> GetPostalCodeByIdAsync(int id);
        Task<List<PostalCode>> GetPostalCodesByCityIdAsync(int cityId);
        Task<int> CreatePostalCodeAsync(PostalCode postalCode);
        Task<bool> UpdatePostalCodeAsync(PostalCode postalCode);
        Task<bool> DeletePostalCodeAsync(int id);
        Task<bool> PostalCodeExistsAsync(int id);
        #endregion
    }
}