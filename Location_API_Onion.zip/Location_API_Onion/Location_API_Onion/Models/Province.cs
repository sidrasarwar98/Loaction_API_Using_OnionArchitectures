﻿namespace Location_API_Onion.Models
{
    public class Province
    {
        public int ProvinceID { get; set; }
        public string ProvinceName { get; set; } = string.Empty;
        public int CountryID { get; set; }
        public string CountryName { get; set; } = string.Empty;
    }
}
