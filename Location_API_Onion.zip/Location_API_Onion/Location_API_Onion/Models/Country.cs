﻿namespace Location_API_Onion.Models
{
    public class Country
    {
        public int CountryID { get; set; }
        public string CountryName { get; set; } = string.Empty;
    }
}
