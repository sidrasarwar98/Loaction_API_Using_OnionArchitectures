﻿namespace Location_API_Onion.Models
{
    public class City
    {
        public int CityID { get; set; }
        public string CityName { get; set; } = string.Empty;
        public int ProvinceID { get; set; }
        public string ProvinceName { get; set; } = string.Empty;
        public int CountryID { get; set; }
        public string CountryName { get; set; } = string.Empty;
    }
}
